/*
** $Id: luasql.c,v 1.26 2008/07/12 15:11:46 carregal Exp $
** See Copyright Notice in license.html
*/

#include <string.h>

#include "lua.h"
#include "lauxlib.h"
#if ! defined (LUA_VERSION_NUM) || LUA_VERSION_NUM < 501
#include "compat-5.1.h"
#endif


#include "luasql.h"

/*
** Typical database error situation
*/
LUASQL_API int luasql_faildirect(lua_State *L, const char *err) {
    lua_pushnil(L);
    lua_pushstring(L, err);
    return 2;
}


/*
** Return the name of the object's metatable.
** This function is used by `tostring'.
*/
static int luasql_tostring (lua_State *L) {
	char buff[100];
	pseudo_data *obj = (pseudo_data *)lua_touserdata (L, 1);
	if (obj->closed)
		strcpy (buff, "closed");
	else
		sprintf (buff, "%p", (void *)obj);
	lua_pushfstring (L, "%s (%s)", lua_tostring(L,lua_upvalueindex(1)), buff);
	return 1;
}


/*
** Create a metatable and leave it on top of the stack.
*/
LUASQL_API int luasql_createmeta (lua_State *L, const char *name, const luaL_reg *methods, lua_CFunction indexfunc) {
	if (!luaL_newmetatable (L, name))
		return 0;

	/* define methods */
	luaL_openlib (L, NULL, methods, 0);

	/* define metamethods */
	lua_pushliteral (L, "__index");
	/* lua_pushvalue (L, -2); */ 
	lua_pushcclosure(L, indexfunc, 0);
	lua_settable (L, -3);
/*
	lua_pushliteral (L, "__newindex");
	lua_pushcclosure(L, newindexfunc, 1);
	lua_settable (L, -3);
*/
	lua_pushliteral (L, "__tostring");
	lua_pushstring (L, name);
	lua_pushcclosure (L, luasql_tostring, 1);
	lua_settable (L, -3);

	lua_pushliteral (L, "__metatable");
	lua_pushliteral (L, LUASQL_PREFIX"you're not allowed to get this metatable");
	lua_settable (L, -3);
/*
	lua_pushstring( L, LUASQL_OPTIONS );
	lua_newtable( L );
	lua_settable( L, -3 );
*/
	return 1;
}


/*
** Define the metatable for the object on top of the stack
*/
LUASQL_API void luasql_setmeta (lua_State *L, const char *name) {
	luaL_getmetatable (L, name);
	lua_setmetatable (L, -2);
}


/*
** Assumes the table is on top of the stack.
*/
LUASQL_API void luasql_set_info (lua_State *L) {
	lua_pushliteral (L, "_COPYRIGHT");
	lua_pushliteral (L, "Copyright (C) 2003-2008 Kepler Project");
	lua_settable (L, -3);
	lua_pushliteral (L, "_DESCRIPTION");
	lua_pushliteral (L, "LuaSQL is a simple interface from Lua to a DBMS");
	lua_settable (L, -3);
	lua_pushliteral (L, "_VERSION");
	lua_pushliteral (L, "LuaSQL 2.1.2");
	lua_settable (L, -3);
}

/*
** Get the mode string value in the options table
*/
LUASQL_API char* luasql_getmodestring( lua_State *L, const char *env ) {
	char* opts;

	luaL_getmetatable( L, env ); /* push luasql environment user data */
	lua_pushstring( L, LUASQL_OPTIONS ); /* put the table options on the stack */
	lua_gettable( L, -2 ); /* get the table */

	lua_pushstring( L, LUASQL_MODESTRING ); /* get locktimeout option */
	lua_gettable( L, -2 );
	opts = lua_tostring( L, -1 );
	lua_pop( L, 3 );

	return opts;
}


/*
** Get the mode string value from cur:fetch parameters
*/
LUASQL_API char* luasql_getfetchmodestring( lua_State *L, const char *env ) {
	char* opts = luasql_getmodestring( L, env );
	
	/* verify if the second parameter is a table */
  	if( lua_istable( L, 3 ) ) {
  		lua_pushstring( L, LUASQL_MODESTRING );
  		lua_gettable( L, 3 );
  		
  		if( lua_isstring( L, -1 ) ) {
  			opts = lua_tostring( L, -1 );
  		}
  		
  		lua_pop( L, 1 );
  	} else {
  		if( lua_isstring( L, 3 ) ) {
  			opts = lua_tostring( L, 3 );
  		}
  	}

	return opts;
}
